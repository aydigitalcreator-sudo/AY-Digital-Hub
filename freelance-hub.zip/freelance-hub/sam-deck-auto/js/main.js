// ===============================
// SAM DECK AUTO - MAIN JAVASCRIPT
// ===============================

// SITE_CONFIG (business contact details) comes from js/config.js
// PRODUCTS array comes from js/products-data.js (both loaded before this file)

const CART_KEY = "samdeck_cart";

// ---- HELPERS ----
function formatNaira(amount) {
    return "₦" + amount.toLocaleString("en-NG");
}

function getCart() {
    try {
        return JSON.parse(localStorage.getItem(CART_KEY)) || {};
    } catch (e) {
        return {};
    }
}

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function findProduct(id) {
    return PRODUCTS.find(p => p.id === id);
}

function cartCount(cart) {
    return Object.values(cart).reduce((sum, qty) => sum + qty, 0);
}

function cartTotalAmount(cart) {
    return Object.entries(cart).reduce((sum, [id, qty]) => {
        const product = findProduct(id);
        return product ? sum + product.price * qty : sum;
    }, 0);
}

// ---- PRODUCT RENDERING ----
function productCardHTML(product) {
    const idAttr = product.anchorId ? ` id="${product.anchorId}"` : "";
    const imageHTML = product.image
        ? `<img src="${product.image}" alt="${product.name}" loading="lazy">`
        : `<span>PRODUCT IMAGE</span>`;
    return `
        <article class="product-card"${idAttr} data-product-id="${product.id}">
            <div class="product-image">
                ${imageHTML}
            </div>
            <div class="product-info">
                <h3>${product.name}</h3>
                <p>${product.desc}</p>
                <div class="product-price">
                    <strong>${formatNaira(product.price)}</strong>
                    <button type="button" class="add-to-cart-btn" data-product-id="${product.id}">
                        Add to Cart
                    </button>
                </div>
            </div>
        </article>`;
}

function renderProducts(containerId, options = {}) {
    const container = document.getElementById(containerId);
    if (!container) return;

    let list = PRODUCTS;

    if (options.query) {
        const q = options.query.toLowerCase();
        list = list.filter(p =>
            p.name.toLowerCase().includes(q) ||
            p.category.toLowerCase().includes(q)
        );
    }

    if (options.limit) {
        list = list.slice(0, options.limit);
    }

    container.innerHTML = list.length
        ? list.map(productCardHTML).join("")
        : '<p class="empty-cart">No products match your search.</p>';
}

// ---- CART RENDERING ----
function updateCart() {
    const cartItems = document.getElementById("cartItems");
    const cartTotal = document.getElementById("cartTotal");
    const cart = getCart();
    const entries = Object.entries(cart);

    if (cartItems) {
        if (entries.length === 0) {
            cartItems.innerHTML = '<p class="empty-cart">Your cart is currently empty.</p>';
        } else {
            cartItems.innerHTML = entries.map(([id, qty]) => {
                const product = findProduct(id);
                if (!product) return "";
                return `
                    <div class="cart-item">
                        <span>${product.name} × ${qty} — ${formatNaira(product.price * qty)}</span>
                        <button type="button" class="remove-from-cart-btn" data-product-id="${id}">
                            Remove
                        </button>
                    </div>`;
            }).join("");
        }
    }

    if (cartTotal) {
        cartTotal.textContent = formatNaira(cartTotalAmount(cart));
    }
}

function addToCart(id) {
    const cart = getCart();
    cart[id] = (cart[id] || 0) + 1;
    saveCart(cart);
    updateCart();
    const product = findProduct(id);
    alert((product ? product.name : "Item") + " added to cart.");
}

function removeFromCart(id) {
    const cart = getCart();
    delete cart[id];
    saveCart(cart);
    updateCart();
}

// ---- CONTACT RENDERING ----
function renderContact() {
    const container = document.getElementById("contactGrid");
    if (!container) return;

    container.innerHTML = `
        <a href="https://wa.me/${SITE_CONFIG.whatsappNumber}" target="_blank" rel="noopener" class="contact-card">
            <span>💬</span>
            <h3>WhatsApp</h3>
            <p>${SITE_CONFIG.whatsappDisplay}</p>
        </a>

        <a href="tel:${SITE_CONFIG.phoneNumber}" class="contact-card">
            <span>📞</span>
            <h3>Call Us</h3>
            <p>${SITE_CONFIG.phoneDisplay}</p>
        </a>

        <div class="contact-card">
            <span>🕒</span>
            <h3>Hours</h3>
            <p>${SITE_CONFIG.hours}</p>
        </div>

        <div class="contact-card">
            <span>📍</span>
            <h3>Location</h3>
            <p>${SITE_CONFIG.address}</p>
        </div>`;
}

// ---- WHATSAPP HELPERS ----
function openWhatsApp(message) {
    const url = `https://wa.me/${SITE_CONFIG.whatsappNumber}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank", "noopener");
}

// ===============================
// DOM READY
// ===============================
document.addEventListener("DOMContentLoaded", () => {

    // Mobile menu
    const menuBtn = document.getElementById("menuBtn");
    const navLinks = document.querySelector(".nav-links");

    if (menuBtn && navLinks) {
        menuBtn.addEventListener("click", () => {
            navLinks.classList.toggle("show");
        });

        navLinks.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => navLinks.classList.remove("show"));
        });
    }

    // Search
    const searchBtn = document.getElementById("searchBtn");
    if (searchBtn) {
        searchBtn.addEventListener("click", () => {
            const query = prompt("What product are you looking for?");
            if (!query || !query.trim()) return;

            const trimmed = query.trim();
            if (document.getElementById("allProductsGrid")) {
                renderProducts("allProductsGrid", { query: trimmed });
            } else {
                window.location.href = "products.html?q=" + encodeURIComponent(trimmed);
            }
        });
    }

    // Render product grids
    if (document.getElementById("productGrid")) {
        renderProducts("productGrid", { limit: 3 });
    }
    if (document.getElementById("allProductsGrid")) {
        const params = new URLSearchParams(window.location.search);
        const q = params.get("q");
        renderProducts("allProductsGrid", q ? { query: q } : {});
    }

    renderContact();

    // Delegated Add to Cart / Remove from Cart clicks (works for dynamically rendered cards)
    document.body.addEventListener("click", (event) => {
        const addBtn = event.target.closest(".add-to-cart-btn");
        if (addBtn) {
            addToCart(addBtn.dataset.productId);
            return;
        }
        const removeBtn = event.target.closest(".remove-from-cart-btn");
        if (removeBtn) {
            removeFromCart(removeBtn.dataset.productId);
        }
    });

    updateCart();

    // Continue to order
    const checkoutBtn = document.getElementById("checkoutBtn");
    const orderSection = document.getElementById("order");

    if (checkoutBtn && orderSection) {
        checkoutBtn.addEventListener("click", () => {
            const cart = getCart();
            if (cartCount(cart) === 0) {
                alert("Please add a product to your cart first.");
                return;
            }
            orderSection.scrollIntoView({ behavior: "smooth" });
        });
    }

    // Order form -> WhatsApp
    const orderForm = document.getElementById("orderForm");
    if (orderForm) {
        orderForm.addEventListener("submit", (event) => {
            event.preventDefault();

            const cart = getCart();
            if (cartCount(cart) === 0) {
                alert("Please add a product to your cart first.");
                return;
            }

            const name = document.getElementById("customerName").value.trim();
            const phone = document.getElementById("customerPhone").value.trim();
            const email = document.getElementById("customerEmail").value.trim();
            const address = document.getElementById("customerAddress").value.trim();

            const itemLines = Object.entries(cart).map(([id, qty]) => {
                const product = findProduct(id);
                if (!product) return "";
                return `- ${product.name} x${qty} (${formatNaira(product.price * qty)})`;
            }).filter(Boolean).join("\n");

            const total = formatNaira(cartTotalAmount(cart));

            const message =
                `New Order — SAM DECK AUTO\n\n` +
                `Name: ${name}\n` +
                `Phone: ${phone}\n` +
                (email ? `Email: ${email}\n` : "") +
                `Delivery Address: ${address}\n\n` +
                `Items:\n${itemLines}\n\n` +
                `Total: ${total}\n\n` +
                `Payment: Bank transfer (please share account details).`;

            openWhatsApp(message);

            const confirmation = document.getElementById("confirmation");
            if (confirmation) {
                confirmation.style.display = "block";
                confirmation.scrollIntoView({ behavior: "smooth" });
            }

            orderForm.reset();
            saveCart({});
            updateCart();
        });
    }

    // Booking form -> WhatsApp
    const bookingForm = document.getElementById("bookingForm");
    if (bookingForm) {
        bookingForm.addEventListener("submit", (event) => {
            event.preventDefault();

            const name = document.getElementById("bookingName").value.trim();
            const phone = document.getElementById("bookingPhone").value.trim();
            const service = document.getElementById("bookingService").value;
            const date = document.getElementById("bookingDate").value;
            const notes = document.getElementById("bookingNotes").value.trim();

            const message =
                `New Service Booking — SAM DECK AUTO\n\n` +
                `Name: ${name}\n` +
                `Phone: ${phone}\n` +
                `Service: ${service}\n` +
                (date ? `Preferred Date: ${date}\n` : "") +
                (notes ? `Notes: ${notes}\n` : "");

            openWhatsApp(message);

            const confirmation = document.getElementById("bookingConfirmation");
            if (confirmation) {
                confirmation.style.display = "block";
                confirmation.scrollIntoView({ behavior: "smooth" });
            }

            bookingForm.reset();
        });
    }

    // Floating WhatsApp button (site-wide)
    const floatBtn = document.createElement("a");
    floatBtn.className = "whatsapp-float";
    floatBtn.href = `https://wa.me/${SITE_CONFIG.whatsappNumber}?text=${encodeURIComponent("Hi SAM DECK AUTO, I have a question.")}`;
    floatBtn.target = "_blank";
    floatBtn.rel = "noopener";
    floatBtn.setAttribute("aria-label", "Chat with us on WhatsApp");
    floatBtn.textContent = "💬";
    document.body.appendChild(floatBtn);

});
