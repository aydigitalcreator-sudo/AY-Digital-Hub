// ===============================
// SAM DECK AUTO - PRODUCT DATA
// Edit product names, descriptions and prices here.
// Do not touch main.js to update products.
// ===============================

const PRODUCTS = [
    { id: "android-system", anchorId: "android", name: "Android Car System", desc: "Premium vehicle multimedia system with CarPlay", price: 85000, category: "Android Systems", image: "assets/products/android-system.jpg" },
    { id: "reverse-camera", anchorId: "camera", name: "Reverse Camera", desc: "Clear and reliable vehicle camera", price: 15000, category: "Reverse Cameras" },
    { id: "gps-tracker", anchorId: "gps", name: "GPS Vehicle Tracker", desc: "Smart vehicle tracking solution", price: 25000, category: "GPS Trackers", image: "assets/products/gps-tracker.jpg" },
    { id: "car-audio", anchorId: "audio", name: "Car Audio System", desc: "Premium sound system upgrade", price: 45000, category: "Car Audio" },
    { id: "dash-cam", anchorId: "accessories", name: "Dash Camera", desc: "Full HD front & rear recording", price: 20000, category: "Accessories" },
    { id: "wireless-charger", anchorId: null, name: "Wireless Car Charger", desc: "Fast wireless phone charging mount", price: 8000, category: "Accessories" },
    { id: "interior-kit", anchorId: null, name: "Interior Upgrade Kit", desc: "Full dashboard & console interior kit", price: 250000, category: "Accessories", image: "assets/products/interior-kit.jpg" },
    { id: "steering-wheel", anchorId: null, name: "GR Steering Wheel Upgrade", desc: "Sport steering wheel with paddle controls", price: 120000, category: "Accessories", image: "assets/products/steering-wheel.jpg" }
];
// NOTE: prices above are placeholders — update them to your real prices.
