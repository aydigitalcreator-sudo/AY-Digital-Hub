// ===============================
// SAM DECK AUTO - SITE CONFIG
// Edit your business contact details here.
// Do not touch main.js to update these.
// ===============================

const SITE_CONFIG = {
    whatsappNumber: "2349063327691",   // international format, no + or spaces
    whatsappDisplay: "0906 332 7691",  // shown on the page
    phoneNumber: "09063327691",        // used for the tel: link
    phoneDisplay: "0906 332 7691",
    hours: "Mon – Sat, 9am – 6pm",
    address: "Update with your shop address"
};
